import serial
ser=None
def plus():
    global ser
    ser.write('s'.encode())
    ser.write('t'.encode())
    ser.write('+'.encode())
def minus():
    global ser
    ser.write('s'.encode())
    ser.write('t'.encode())
    ser.write('-'.encode())
def fire():
    global ser
    ser.write('s'.encode())
    ser.write('t'.encode())
    ser.write('*'.encode())
def connect(com=None):
    global ser
    if com==None:
        print('请输入端口号(请注意大小写):')
        com=input()
    ser=serial.Serial(com,9600)
